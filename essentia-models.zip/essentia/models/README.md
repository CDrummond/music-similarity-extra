Essentia high-level models from https://essentia.upf.edu/svm_models/essentia-extractor-svm_models-v2.1_beta1.tar.gz
